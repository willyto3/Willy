# Diseñar 3 funciones:
#
#   1. Leer un número de 4 dígitos, mostrar el dígito mayor e 
#      informar si es par o impar.
#   2. Leer dos números de 3 dígitos cada uno, formar un tercer número 
#      con el mayor del primero y el menor del segundo.
#   3. Leer un número de 3 dígitos y formar el mayor número posible 
#      con sus cifras.
#   
# Crea la función principal como un menú con las tres opciones.

def funcion1():
   
    print("El mayor dígito es " ) 

def funcion2():

    print("El nuevo dígito es " )

def funcion3():
    

    print("El nuevo dígito es ")

if __name__ == "__main__":
    
